package service;

import dao.OdontologoDAOH2;
import dao.OdontologoDao;
import dao.PacienteDAOH2;
import dao.iDao;
import model.Odontologo;
import model.Paciente;

public class OdontologoService {
    private iDao<Odontologo> odontologoiDao;

    public OdontologoService() {
        odontologoiDao = new OdontologoDAOH2();
    }

    public OdontologoService(boolean algo){
        odontologoiDao = (iDao<Odontologo>) new OdontologoDao();
    }
    public Odontologo guardarOdontologo(Odontologo odontologo){return odontologoiDao.guardar(odontologo);}

    public  Odontologo listarTodos(){return odontologoiDao.listarTodos();}

    public Odontologo guardarOdontologoNoBD(Odontologo odontologo){return odontologoiDao.guardar(odontologo);}

    public Odontologo listarTodosNoBD(){return odontologoiDao.listarTodos();}
}
