import dao.BD;
import dao.OdontologoDao;
import model.Odontologo;
import org.junit.jupiter.api.Test;
import service.OdontologoService;

public class OdontologoTestService {
    /*
    @Test
    public void guardarOdontologo(){
        BD.crearTablas();
        Odontologo odontologo = new Odontologo(1234, "Abraham", "Domínguez");
        Odontologo odontologo2 = new Odontologo(5678, "Avril", "Tihista");
        OdontologoService odontologoService = new OdontologoService();
        odontologoService.guardarOdontologo(odontologo);
        odontologoService.guardarOdontologo(odontologo2);

    }
    */
    @Test
    public void listarTodos(){
        BD.crearTablas();
        Odontologo odontologo = new Odontologo(1234, "Abraham", "Domínguez");
        Odontologo odontologo2 = new Odontologo(5678, "Avril", "Tihista");
        OdontologoService odontologoService = new OdontologoService();
        odontologoService.guardarOdontologo(odontologo);
        odontologoService.guardarOdontologo(odontologo2);
        odontologoService.listarTodos();
    }
    @Test
    public void listarTodosNoBD(){
        Odontologo odontologo = new Odontologo(1234, "Abraham", "Domínguez");
        Odontologo odontologo2 = new Odontologo(5678, "Avril", "Tihista");
        OdontologoService odontologoService = new OdontologoService();
        odontologoService.guardarOdontologoNoBD(odontologo);
        odontologoService.guardarOdontologoNoBD(odontologo2);
        odontologoService.listarTodosNoBD();
    }
}
