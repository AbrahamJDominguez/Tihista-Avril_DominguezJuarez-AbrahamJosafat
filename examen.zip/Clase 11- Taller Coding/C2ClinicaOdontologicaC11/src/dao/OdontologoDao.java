package dao;

import model.Odontologo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

public class OdontologoDao {
    private static final HashMap<Integer,Odontologo> odontologos = new HashMap<>();

    public Odontologo guardar(Odontologo odontologo){
        Integer id = 0;
        if(odontologos.isEmpty()){
            id = 1;
        } else{
            id = Collections.max(odontologos.keySet()) + 1;
        }
        odontologo.setId(id);
        odontologos.put(id, odontologo);
        return odontologo;
    }

    public Odontologo listarTodos(){
        //id
        //matricula
        //nombre
        //apellido
        System.out.println("ID\t\tMatricula\t\tNombre\t\tApellido\n");
        String odontologoStr = "";
        for (Map.Entry<Integer, Odontologo> odontologoEntry :
             odontologos.entrySet()) {
            Odontologo odontologo = odontologoEntry.getValue();
            //imprimir
            odontologoStr += odontologo.getId() + "\t\t" + odontologo.getMatricula() + "\t\t" + odontologo.getNombre() + "\t\t" + odontologo.getApellido();
            System.out.println(odontologoStr);
            odontologoStr = "";
        }
        return null;
    }

}
