package dao;

import model.Odontologo;
import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

public class OdontologoDAOH2 implements iDao<Odontologo>{

    //Logger
    private static final Logger logger= Logger.getLogger(OdontologoDAOH2.class);

    private static final String SQL_INSERT="INSERT INTO ODONTOLOGOS (MATRICULA, NOMBRE, APELLIDO) VALUES(?,?,?)";

    @Override
    public Odontologo guardar(Odontologo odontologo) {
        logger.info("inicando la operacion de guardado");
        Connection connection = null;
        try{
            connection = BD.getConnection();
            PreparedStatement psInsert= connection.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS);
            psInsert.setInt(1, odontologo.getMatricula());
            psInsert.setString(2, odontologo.getNombre());
            psInsert.setString(3, odontologo.getApellido());
            psInsert.execute();
            ResultSet rs= psInsert.getGeneratedKeys();
            while (rs.next()){
               odontologo.setId(rs.getInt(1));
            }
            logger.info("Odontologo guardado con exito");
        }catch(Exception e){
            logger.warn(e.getMessage());
        }
        return odontologo;
    }

    @Override
    public Odontologo buscarPorID(Integer id) {
        return null;
    }

    @Override
    public void actualizar(Odontologo odontologo) {

    }

    @Override
    public void eliminar(Integer id) {

    }

    @Override
    public List<Odontologo> buscarTodos() {
        return null;
    }

    @Override
    public Odontologo listarTodos() {
        Connection connection = null;

        try {
            connection = BD.getConnection();
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM ODONTOLOGOS");
            //ejecutar
            ResultSet rs = ps.executeQuery();

            //id
            //matricula
            //nombre
            //apellido

            System.out.println("ID\t\tMatricula\t\tNombre\t\tApellido\n");

            String odontologoStr = "";
            //evaluar resultados
            while (rs.next()) {
                Odontologo odontologo = new Odontologo();
                odontologo.setId(rs.getInt("id"));
                odontologo.setMatricula(rs.getInt("matricula"));
                odontologo.setNombre(rs.getString("nombre"));
                odontologo.setApellido(rs.getString("apellido"));

                //imprimir

                odontologoStr += odontologo.getId() + "\t\t" + odontologo.getMatricula() + "\t\t" + odontologo.getNombre() + "\t\t" + odontologo.getApellido();
                System.out.println(odontologoStr);
                odontologoStr = "";
            }
            ps.close();

        }catch(Exception e){
           logger.warn(e.getMessage());
        }
        return null;
    }
}
